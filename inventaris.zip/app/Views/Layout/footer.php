<footer class="footer my-3">
    <div class="row text-center">
        <div class="col-md-12">
            &copy; 2024 <strong><span>lammmzt</span></strong>. All Rights Reserved
        </div>
    </div>
</footer>